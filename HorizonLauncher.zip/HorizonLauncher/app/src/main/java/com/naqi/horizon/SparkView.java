package com.naqi.horizon;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;

import java.util.ArrayList;

/** Small gold price line, built from the prices fetched since the launcher started. */
public class SparkView extends View {

    private final ArrayList<Float> points = new ArrayList<>();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    public SparkView(Context context) {
        this(context, null);
    }

    public SparkView(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setColor(0xFFFBBF24);
        paint.setStrokeWidth(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 2, getResources().getDisplayMetrics()));
    }

    public void add(float v) {
        points.add(v);
        if (points.size() > 60) points.remove(0);
        invalidate();
    }

    public boolean hasData() {
        return !points.isEmpty();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (points.size() < 2) return;
        float min = Float.MAX_VALUE, max = -Float.MAX_VALUE;
        for (float v : points) {
            min = Math.min(min, v);
            max = Math.max(max, v);
        }
        float pad = paint.getStrokeWidth();
        float w = getWidth() - pad * 2;
        float h = getHeight() - pad * 2;
        float range = max - min;
        path.reset();
        for (int i = 0; i < points.size(); i++) {
            float x = pad + w * i / (points.size() - 1);
            float y = range == 0 ? getHeight() / 2f : pad + h * (1 - (points.get(i) - min) / range);
            if (i == 0) path.moveTo(x, y);
            else path.lineTo(x, y);
        }
        c.drawPath(path, paint);
    }
}
