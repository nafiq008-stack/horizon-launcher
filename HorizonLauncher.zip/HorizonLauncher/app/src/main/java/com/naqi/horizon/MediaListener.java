package com.naqi.horizon;

import android.service.notification.NotificationListenerService;

/**
 * Empty listener. Android only lets a launcher read the song name, artist and
 * cover of the music app that is playing when this service has
 * "Notification access" turned on in Settings.
 */
public class MediaListener extends NotificationListenerService {
}
