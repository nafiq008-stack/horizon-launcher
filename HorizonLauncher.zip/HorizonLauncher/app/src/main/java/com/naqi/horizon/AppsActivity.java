package com.naqi.horizon;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * App drawer. Also used to pick which app a Horizon shortcut opens
 * (started with EXTRA_SLOT, returns EXTRA_PKG).
 */
public class AppsActivity extends Activity {

    static final String EXTRA_SLOT = "slot";
    static final String EXTRA_TITLE = "title";
    static final String EXTRA_PKG = "pkg";

    static class Entry {
        String label;
        String pkg;
        String cls;
        ResolveInfo info;
        Drawable icon;
    }

    private final List<Entry> entries = new ArrayList<>();
    private String slot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apps);
        slot = getIntent().getStringExtra(EXTRA_SLOT);

        TextView title = findViewById(R.id.title);
        String t = getIntent().getStringExtra(EXTRA_TITLE);
        title.setText(slot != null && t != null ? t : "All apps");
        findViewById(R.id.close).setOnClickListener(v -> finish());

        final PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = pm.queryIntentActivities(main, 0);
        for (ResolveInfo ri : found) {
            if (ri.activityInfo == null || getPackageName().equals(ri.activityInfo.packageName)) continue;
            Entry e = new Entry();
            e.info = ri;
            e.pkg = ri.activityInfo.packageName;
            e.cls = ri.activityInfo.name;
            CharSequence l = ri.loadLabel(pm);
            e.label = l != null ? l.toString() : e.pkg;
            entries.add(e);
        }
        Collections.sort(entries, (a, b) -> a.label.compareToIgnoreCase(b.label));

        GridView grid = findViewById(R.id.grid);
        grid.setAdapter(new BaseAdapter() {
            @Override
            public int getCount() {
                return entries.size();
            }

            @Override
            public Object getItem(int position) {
                return entries.get(position);
            }

            @Override
            public long getItemId(int position) {
                return position;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = convertView != null ? convertView
                        : LayoutInflater.from(AppsActivity.this).inflate(R.layout.item_app, parent, false);
                Entry e = entries.get(position);
                if (e.icon == null) e.icon = e.info.loadIcon(pm);
                ((ImageView) v.findViewById(R.id.icon)).setImageDrawable(e.icon);
                ((TextView) v.findViewById(R.id.label)).setText(e.label);
                return v;
            }
        });

        grid.setOnItemClickListener((parent, view, position, id) -> {
            Entry e = entries.get(position);
            if (slot != null) {
                Intent result = new Intent();
                result.putExtra(EXTRA_SLOT, slot);
                result.putExtra(EXTRA_PKG, e.pkg);
                setResult(RESULT_OK, result);
                finish();
                return;
            }
            Intent launch = new Intent(Intent.ACTION_MAIN);
            launch.addCategory(Intent.CATEGORY_LAUNCHER);
            launch.setClassName(e.pkg, e.cls);
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            try {
                startActivity(launch);
            } catch (Exception ignored) {
            }
            finish();
        });

        grid.setOnItemLongClickListener((parent, view, position, id) -> {
            Entry e = entries.get(position);
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + e.pkg)));
            } catch (Exception ignored) {
            }
            return true;
        });
    }
}
