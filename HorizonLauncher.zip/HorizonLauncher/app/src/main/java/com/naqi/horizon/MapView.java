package com.naqi.horizon;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

/** Decorative night-map background for the Drive panel. */
public class MapView extends View {

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    public MapView(Context context) {
        super(context);
    }

    public MapView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float sx = getWidth() / 480f;
        float sy = getHeight() / 290f;
        c.save();
        c.scale(sx, sy);

        // Parks
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF101A16);
        c.drawRoundRect(300, 20, 440, 100, 14, 14, p);
        c.drawRoundRect(20, 200, 130, 270, 14, 14, p);

        // River
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setColor(0xFF0E1A2A);
        p.setStrokeWidth(26);
        path.reset();
        path.moveTo(-10, 150);
        path.cubicTo(90, 120, 170, 190, 280, 150);
        path.cubicTo(390, 110, 420, 110, 500, 140);
        c.drawPath(path, p);

        // Streets
        p.setStrokeCap(Paint.Cap.BUTT);
        p.setColor(0xFF1B2029);
        p.setStrokeWidth(6);
        float[] ys = {70, 190, 262};
        for (float y : ys) c.drawLine(0, y, 480, y, p);
        float[] xs = {90, 200, 330, 420};
        for (float x : xs) c.drawLine(x, 0, x, 290, p);
        p.setColor(0xFF171B23);
        p.setStrokeWidth(3);
        c.drawLine(0, 250, 480, 90, p);
        c.drawLine(50, 0, 270, 290, p);

        // Route
        path.reset();
        path.moveTo(150, 262);
        path.lineTo(200, 262);
        path.lineTo(200, 190);
        path.lineTo(330, 190);
        path.lineTo(330, 70);
        path.lineTo(380, 58);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(0x2EFF8A4C);
        p.setStrokeWidth(11);
        c.drawPath(path, p);
        p.setColor(MainActivity.ACCENT);
        p.setStrokeWidth(4);
        c.drawPath(path, p);

        // Destination
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF0D1117);
        c.drawCircle(380, 58, 8, p);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(MainActivity.ACCENT);
        p.setStrokeWidth(3);
        c.drawCircle(380, 58, 8, p);

        // Car
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x2EFF8A4C);
        c.drawCircle(150, 262, 18, p);
        p.setColor(Color.WHITE);
        path.reset();
        path.moveTo(150, 250);
        path.lineTo(160, 272);
        path.lineTo(150, 266);
        path.lineTo(140, 272);
        path.close();
        c.drawPath(path, p);

        c.restore();
    }
}
