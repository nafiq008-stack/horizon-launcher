package com.naqi.horizon;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Horizon home screen for the Proton Persona head unit (Android 6).
 */
public class MainActivity extends Activity {

    static final int ACCENT = 0xFFFF8A4C;
    static final int SELECTED = 0xFF1C222C;
    static final int TEXT = 0xFFF3F4F6;
    static final int MUTED = 0xFF8B93A3;
    static final int DOCK_TEXT = 0xFFAEB4C0;
    static final int DARK = 0xFF0A0C10;
    static final int BUTTON = 0xFF151A22;
    static final int QUICK_OFF = 0xFF1A2029;
    static final int REQ_PICK = 7;
    static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;

    /** Shortcut slots and the apps tried by default, in order. Long-press any of them to change. */
    static final String[][] DEFAULTS = {
            {"waze", "com.waze"},
            {"maps", "com.google.android.apps.maps"},
            {"music", "com.spotify.music", "com.google.android.apps.youtube.music", "com.android.music"},
            {"video", "com.google.android.youtube"},
            {"radio"},
            {"phone"},
            {"trade", "net.metaquotes.metatrader5", "net.metaquotes.metatrader4"},
    };

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;

    private final View[] panels = new View[3];
    private final LinearLayout[] tabs = new LinearLayout[3];
    private int mode = 0;

    private TextView dateText, greetText, tempText, goldPrice, goldSub, speedText;
    private TextView sourceText, songTitle, songArtist, mediaHint, phoneSub;
    private ImageView weatherIcon, art, playIcon;
    private ProgressBar mediaProgress;
    private SparkView goldSpark;
    private LinearLayout favRow;
    private Quick qBt, qWifi;

    private MediaSessionManager msm;
    private MediaController controller;
    private ComponentName listenerCn;
    private LocationManager lm;
    private Location lastLoc;
    private boolean receiverOn;

    static class Quick {
        LinearLayout root;
        FrameLayout circle;
        ImageView icon;
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("horizon", MODE_PRIVATE);
        listenerCn = new ComponentName(this, MediaListener.class);
        msm = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        dateText = findViewById(R.id.dateText);
        greetText = findViewById(R.id.greetText);
        tempText = findViewById(R.id.tempText);
        weatherIcon = findViewById(R.id.weatherIcon);
        goldPrice = findViewById(R.id.goldPrice);
        goldSub = findViewById(R.id.goldSub);
        goldSpark = findViewById(R.id.goldSpark);
        speedText = findViewById(R.id.speedText);
        sourceText = findViewById(R.id.sourceText);
        songTitle = findViewById(R.id.songTitle);
        songArtist = findViewById(R.id.songArtist);
        mediaHint = findViewById(R.id.mediaHint);
        art = findViewById(R.id.art);
        playIcon = findViewById(R.id.playIcon);
        mediaProgress = findViewById(R.id.mediaProgress);
        favRow = findViewById(R.id.favRow);
        phoneSub = findViewById(R.id.phoneSub);

        panels[0] = findViewById(R.id.panelDrive);
        panels[1] = findViewById(R.id.panelMedia);
        panels[2] = findViewById(R.id.panelPhone);

        buildTabs();
        buildDriveBar();
        buildMediaControls();
        buildPhoneButtons();
        buildQuick();
        buildDock();

        findViewById(R.id.speedBadge).setBackground(round(ACCENT, 11));
        // Round the corners of the map and the album cover (Android 5+).
        panels[0].setClipToOutline(true);
        art.setClipToOutline(true);

        View goldCard = findViewById(R.id.goldCard);
        goldCard.setOnClickListener(v -> openSlot("trade"));
        goldCard.setOnLongClickListener(v -> {
            pickFor("trade");
            return true;
        });

        setMode(prefs.getInt("mode", 0));
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateTexts();
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_TIME_TICK);
        f.addAction(Intent.ACTION_TIME_CHANGED);
        f.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        f.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        f.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        registerReceiver(receiver, f);
        receiverOn = true;

        refreshQuick();
        startLocation();
        connectMedia();
        refreshFavs();
        ui.post(goldTick);
        ui.postDelayed(weatherTick, 1500);
        ui.post(mediaTick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (receiverOn) {
            unregisterReceiver(receiver);
            receiverOn = false;
        }
        try {
            if (lm != null) lm.removeUpdates(locListener);
        } catch (Exception ignored) {
        }
        disconnectMedia();
        ui.removeCallbacks(goldTick);
        ui.removeCallbacks(weatherTick);
        ui.removeCallbacks(mediaTick);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow();
    }

    @Override
    public void onBackPressed() {
        // A home screen has nowhere to go back to; Back just returns to the Drive view.
        if (mode != 0) setMode(0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK && resultCode == RESULT_OK && data != null) {
            String slot = data.getStringExtra(AppsActivity.EXTRA_SLOT);
            String pkg = data.getStringExtra(AppsActivity.EXTRA_PKG);
            if (slot != null && pkg != null) {
                prefs.edit().putString("slot_" + slot, pkg).apply();
                Toast.makeText(this, "Saved. Long-press to change it later.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // ------------------------------------------------------------------ building the UI

    private void buildTabs() {
        LinearLayout bar = findViewById(R.id.tabBar);
        String[] labels = {"Drive", "Media", "Phone"};
        int[] icons = {R.drawable.ic_nav, R.drawable.ic_music, R.drawable.ic_phone};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            LinearLayout t = iconLabel(icons[i], labels[i], 16, 14, MUTED, false, 8);
            t.setOnClickListener(v -> setMode(idx));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, MATCH, 1f);
            if (i > 0) lp.leftMargin = dp(4);
            bar.addView(t, lp);
            tabs[i] = t;
        }
    }

    private void setMode(int m) {
        if (m < 0 || m > 2) m = 0;
        mode = m;
        prefs.edit().putInt("mode", m).apply();
        for (int i = 0; i < 3; i++) {
            boolean on = i == m;
            panels[i].setVisibility(on ? View.VISIBLE : View.GONE);
            tabs[i].setBackground(on ? round(SELECTED, 10) : ripple(null, 10));
            tintIconLabel(tabs[i], on ? Color.WHITE : MUTED);
        }
    }

    private void buildDriveBar() {
        LinearLayout bar = findViewById(R.id.driveBar);

        LinearLayout home = iconLabel(R.drawable.ic_home, "Home", 18, 14, TEXT, false, 8);
        styleChip(home);
        home.setOnClickListener(v -> wazeFavourite("home"));
        bar.addView(home, new LinearLayout.LayoutParams(WRAP, dp(42)));

        LinearLayout work = iconLabel(R.drawable.ic_work, "Work", 18, 14, TEXT, false, 8);
        styleChip(work);
        work.setOnClickListener(v -> wazeFavourite("work"));
        LinearLayout.LayoutParams wl = new LinearLayout.LayoutParams(WRAP, dp(42));
        wl.leftMargin = dp(8);
        bar.addView(work, wl);

        bar.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));

        TextView waze = textButton("Open Waze", 0xFFF3F4F6, DARK, 11);
        waze.setPadding(dp(18), 0, dp(18), 0);
        waze.setOnClickListener(v -> openSlot("waze"));
        waze.setOnLongClickListener(v -> {
            pickFor("waze");
            return true;
        });
        bar.addView(waze, new LinearLayout.LayoutParams(WRAP, dp(42)));
    }

    private void styleChip(LinearLayout chip) {
        chip.setPadding(dp(14), 0, dp(16), 0);
        chip.setBackground(ripple(round(SELECTED, 11), 11));
    }

    private void buildMediaControls() {
        View prev = findViewById(R.id.btnPrev);
        View play = findViewById(R.id.btnPlay);
        View next = findViewById(R.id.btnNext);
        prev.setBackground(ripple(oval(0x12FFFFFF), -1));
        next.setBackground(ripple(oval(0x12FFFFFF), -1));
        play.setBackground(ripple(oval(ACCENT), -1));
        prev.setOnClickListener(v -> mediaAction(KeyEvent.KEYCODE_MEDIA_PREVIOUS));
        next.setOnClickListener(v -> mediaAction(KeyEvent.KEYCODE_MEDIA_NEXT));
        play.setOnClickListener(v -> mediaAction(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE));

        art.setOnClickListener(v -> openSlot("music"));
        art.setOnLongClickListener(v -> {
            pickFor("music");
            return true;
        });
        mediaHint.setOnClickListener(v -> {
            if (!safeStart(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))) {
                Toast.makeText(this, "This head unit hides that setting. The music buttons still work.", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void buildPhoneButtons() {
        LinearLayout row = findViewById(R.id.phoneButtons);
        TextView recent = textButton("Recent calls", BUTTON, TEXT, 14);
        recent.setOnClickListener(v -> {
            if (!safeStart(new Intent(Intent.ACTION_VIEW, CallLog.Calls.CONTENT_URI))) {
                safeStart(new Intent(Intent.ACTION_DIAL));
            }
        });
        TextView keypad = textButton("Keypad", BUTTON, TEXT, 14);
        keypad.setOnClickListener(v -> safeStart(new Intent(Intent.ACTION_DIAL)));
        TextView phoneApp = textButton("Phone app", ACCENT, DARK, 14);
        phoneApp.setOnClickListener(v -> openSlot("phone"));
        phoneApp.setOnLongClickListener(v -> {
            pickFor("phone");
            return true;
        });
        TextView[] all = {recent, keypad, phoneApp};
        for (int i = 0; i < all.length; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, MATCH, 1f);
            if (i > 0) lp.leftMargin = dp(10);
            row.addView(all[i], lp);
        }
    }

    private void buildQuick() {
        LinearLayout row = findViewById(R.id.quick);
        Quick sun = addQuick(row, R.drawable.ic_sun, "Brightness");
        Quick vol = addQuick(row, R.drawable.ic_volume, "Volume");
        qBt = addQuick(row, R.drawable.ic_bt, "Bluetooth");
        qWifi = addQuick(row, R.drawable.ic_wifi, "Wi-Fi");
        styleQuick(sun, false);
        styleQuick(vol, false);

        sun.root.setOnClickListener(v -> showBrightness());
        vol.root.setOnClickListener(v -> {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI);
        });
        qBt.root.setOnClickListener(v -> toggleBluetooth());
        qBt.root.setOnLongClickListener(v -> {
            safeStart(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            return true;
        });
        qWifi.root.setOnClickListener(v -> toggleWifi());
        qWifi.root.setOnLongClickListener(v -> {
            safeStart(new Intent(Settings.ACTION_WIFI_SETTINGS));
            return true;
        });
    }

    private Quick addQuick(LinearLayout parent, int icon, String label) {
        Quick q = new Quick();
        q.root = new LinearLayout(this);
        q.root.setOrientation(LinearLayout.VERTICAL);
        q.root.setGravity(Gravity.CENTER);
        q.circle = new FrameLayout(this);
        q.icon = new ImageView(this);
        q.icon.setImageResource(icon);
        q.circle.addView(q.icon, new FrameLayout.LayoutParams(dp(19), dp(19), Gravity.CENTER));
        q.root.addView(q.circle, new LinearLayout.LayoutParams(dp(46), dp(46)));
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(0xFFC9CED8);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        t.setSingleLine(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
        lp.topMargin = dp(6);
        q.root.addView(t, lp);
        q.root.setBackground(ripple(null, 14));
        parent.addView(q.root, new LinearLayout.LayoutParams(0, MATCH, 1f));
        return q;
    }

    private void styleQuick(Quick q, boolean on) {
        q.circle.setBackground(oval(on ? ACCENT : QUICK_OFF));
        q.icon.setImageTintList(ColorStateList.valueOf(on ? DARK : 0xFFE5E7EB));
    }

    private void buildDock() {
        LinearLayout dock = findViewById(R.id.dock);
        String[][] items = {
                {"waze", "Waze"}, {"maps", "Maps"}, {"music", "Music"}, {"video", "Video"},
                {"radio", "Radio"}, {"settings", "Settings"}, {"apps", "Apps"}};
        int[] icons = {R.drawable.ic_nav, R.drawable.ic_map, R.drawable.ic_music, R.drawable.ic_video,
                R.drawable.ic_radio, R.drawable.ic_sliders, R.drawable.ic_apps};
        for (int i = 0; i < items.length; i++) {
            final String id = items[i][0];
            LinearLayout it = iconLabel(icons[i], items[i][1], 20, 13, DOCK_TEXT, false, 8);
            it.setBackground(ripple(null, 16));
            it.setOnClickListener(v -> openSlot(id));
            it.setOnLongClickListener(v -> {
                if (isConfigurable(id)) pickFor(id);
                return true;
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(58), 1f);
            if (i > 0) lp.leftMargin = dp(4);
            dock.addView(it, lp);
        }
    }

    // ------------------------------------------------------------------ clock, greeting

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (Intent.ACTION_TIME_TICK.equals(a) || Intent.ACTION_TIME_CHANGED.equals(a)
                    || Intent.ACTION_TIMEZONE_CHANGED.equals(a)) {
                updateTexts();
            } else {
                refreshQuick();
            }
        }
    };

    private void updateTexts() {
        Calendar c = Calendar.getInstance();
        dateText.setText(new SimpleDateFormat("EEEE, d MMM", Locale.US).format(c.getTime()));
        int h = c.get(Calendar.HOUR_OF_DAY);
        String g = h < 12 ? "Good morning" : h < 19 ? "Good afternoon" : "Good evening";
        greetText.setText(g + ", " + getString(R.string.driver_name));
    }

    // ------------------------------------------------------------------ shortcuts

    private boolean isConfigurable(String id) {
        for (String[] d : DEFAULTS) if (d[0].equals(id)) return true;
        return false;
    }

    private void openSlot(String id) {
        if ("settings".equals(id)) {
            safeStart(new Intent(Settings.ACTION_SETTINGS));
            return;
        }
        if ("apps".equals(id)) {
            startActivity(new Intent(this, AppsActivity.class));
            return;
        }
        String pkg = slotPackage(id);
        if (pkg == null) {
            pickFor(id);
            return;
        }
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) {
            prefs.edit().remove("slot_" + id).apply();
            pickFor(id);
            return;
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        safeStart(i);
    }

    private String slotPackage(String id) {
        String saved = prefs.getString("slot_" + id, null);
        if (saved != null && installed(saved)) return saved;
        for (String[] d : DEFAULTS) {
            if (!d[0].equals(id)) continue;
            for (int k = 1; k < d.length; k++) if (installed(d[k])) return d[k];
        }
        return null;
    }

    private boolean installed(String pkg) {
        return getPackageManager().getLaunchIntentForPackage(pkg) != null;
    }

    private void pickFor(String id) {
        Intent i = new Intent(this, AppsActivity.class);
        i.putExtra(AppsActivity.EXTRA_SLOT, id);
        i.putExtra(AppsActivity.EXTRA_TITLE, "Choose the app for " + slotName(id));
        startActivityForResult(i, REQ_PICK);
    }

    private String slotName(String id) {
        switch (id) {
            case "waze": return "navigation";
            case "maps": return "maps";
            case "music": return "music";
            case "video": return "video";
            case "radio": return "radio";
            case "phone": return "phone calls";
            case "trade": return "the gold card";
            default: return id;
        }
    }

    private void wazeFavourite(String which) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("waze://?favorite=" + which + "&navigate=yes"));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (!safeStart(i)) {
            Toast.makeText(this, "Install Waze and save your " + which + " address in it.", Toast.LENGTH_LONG).show();
        }
    }

    private boolean safeStart(Intent i) {
        try {
            startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ------------------------------------------------------------------ quick controls

    private void refreshQuick() {
        BluetoothAdapter ba = BluetoothAdapter.getDefaultAdapter();
        boolean bt = false;
        try {
            bt = ba != null && ba.isEnabled();
        } catch (Exception ignored) {
        }
        boolean wifi = false;
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            wifi = wm != null && wm.isWifiEnabled();
        } catch (Exception ignored) {
        }
        styleQuick(qBt, bt);
        styleQuick(qWifi, wifi);
    }

    private void toggleBluetooth() {
        BluetoothAdapter ba = BluetoothAdapter.getDefaultAdapter();
        if (ba == null) {
            safeStart(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            return;
        }
        try {
            if (ba.isEnabled()) ba.disable();
            else ba.enable();
        } catch (Exception e) {
            safeStart(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        }
        ui.postDelayed(this::refreshQuick, 1500);
    }

    private void toggleWifi() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            wm.setWifiEnabled(!wm.isWifiEnabled());
        } catch (Exception e) {
            safeStart(new Intent(Settings.ACTION_WIFI_SETTINGS));
        }
        ui.postDelayed(this::refreshQuick, 1500);
    }

    private void showBrightness() {
        final SeekBar bar = new SeekBar(this);
        bar.setMax(255);
        int current = 150;
        try {
            current = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
        } catch (Exception ignored) {
        }
        bar.setProgress(current);
        bar.setPadding(dp(28), dp(28), dp(28), dp(28));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (!fromUser) return;
                int v = Math.max(5, p);
                try {
                    Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                            Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                    Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, v);
                } catch (Exception ignored) {
                }
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.screenBrightness = v / 255f;
                getWindow().setAttributes(lp);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Brightness")
                .setView(bar)
                .setPositiveButton("Done", null)
                .setNeutralButton("Display settings", (d, w) -> safeStart(new Intent(Settings.ACTION_DISPLAY_SETTINGS)))
                .show();
    }

    // ------------------------------------------------------------------ GPS speed

    private final LocationListener locListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location l) {
            lastLoc = l;
            int kmh = l.hasSpeed() ? Math.round(l.getSpeed() * 3.6f) : 0;
            speedText.setText(String.valueOf(kmh));
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onProviderDisabled(String provider) {
            speedText.setText("--");
        }
    };

    private void startLocation() {
        try {
            if (lm == null || !lm.getAllProviders().contains(LocationManager.GPS_PROVIDER)) {
                speedText.setText("--");
                return;
            }
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, locListener);
            Location l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (l == null && lm.getAllProviders().contains(LocationManager.NETWORK_PROVIDER)) {
                l = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            }
            if (l != null) lastLoc = l;
        } catch (Exception e) {
            speedText.setText("--");
        }
    }

    // ------------------------------------------------------------------ gold and weather

    private final Runnable goldTick = new Runnable() {
        @Override
        public void run() {
            fetchGold();
            ui.postDelayed(this, 60_000);
        }
    };

    private final Runnable weatherTick = new Runnable() {
        @Override
        public void run() {
            fetchWeather();
            ui.postDelayed(this, 30 * 60_000);
        }
    };

    private String httpGet(String address) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(address).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 6.0) HorizonLauncher/1.0");
        c.setRequestProperty("Accept", "application/json");
        try {
            if (c.getResponseCode() != 200) throw new IOException("HTTP " + c.getResponseCode());
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();
            return sb.toString();
        } finally {
            c.disconnect();
        }
    }

    private void fetchGold() {
        io.execute(() -> {
            double p = -1;
            try {
                p = new JSONObject(httpGet("https://api.gold-api.com/price/XAU")).getDouble("price");
            } catch (Exception ignored) {
            }
            if (p <= 0) {
                try {
                    p = new JSONObject(httpGet("https://data-asg.goldprice.org/dbXRates/USD"))
                            .getJSONArray("items").getJSONObject(0).getDouble("xauPrice");
                } catch (Exception ignored) {
                }
            }
            final double price = p;
            ui.post(() -> showGold(price));
        });
    }

    private void showGold(double p) {
        if (p > 0) {
            goldPrice.setText(String.format(Locale.US, "%,.2f", p));
            goldSub.setText("Updated " + new SimpleDateFormat("h:mm a", Locale.US).format(new Date()));
            goldSpark.add((float) p);
        } else if (!goldSpark.hasData()) {
            goldPrice.setText("—");
            goldSub.setText("No internet connection");
        }
    }

    private void fetchWeather() {
        final double lat = lastLoc != null ? lastLoc.getLatitude() : 3.1390;
        final double lon = lastLoc != null ? lastLoc.getLongitude() : 101.6869;
        io.execute(() -> {
            try {
                String url = String.format(Locale.US,
                        "https://api.open-meteo.com/v1/forecast?latitude=%.3f&longitude=%.3f&current=temperature_2m,weather_code&timezone=auto",
                        lat, lon);
                JSONObject cur = new JSONObject(httpGet(url)).getJSONObject("current");
                final int t = (int) Math.round(cur.getDouble("temperature_2m"));
                final int code = cur.getInt("weather_code");
                ui.post(() -> {
                    tempText.setText(t + "°C");
                    weatherIcon.setImageResource(code <= 1 ? R.drawable.ic_sun
                            : code < 51 ? R.drawable.ic_cloud : R.drawable.ic_rain);
                    weatherIcon.setImageTintList(ColorStateList.valueOf(code <= 1 ? 0xFFFCD34D : 0xFFC9CED8));
                });
            } catch (Exception ignored) {
            }
        });
    }

    // ------------------------------------------------------------------ media

    private final MediaSessionManager.OnActiveSessionsChangedListener sessionsListener =
            new MediaSessionManager.OnActiveSessionsChangedListener() {
                @Override
                public void onActiveSessionsChanged(List<MediaController> list) {
                    pickController(list);
                }
            };

    private final MediaController.Callback mediaCallback = new MediaController.Callback() {
        @Override
        public void onMetadataChanged(MediaMetadata metadata) {
            updateMedia();
        }

        @Override
        public void onPlaybackStateChanged(PlaybackState state) {
            updateMedia();
        }

        @Override
        public void onSessionDestroyed() {
            setController(null);
        }
    };

    private final Runnable mediaTick = new Runnable() {
        @Override
        public void run() {
            updateProgress();
            ui.postDelayed(this, 1000);
        }
    };

    private void connectMedia() {
        if (msm == null) {
            mediaHint.setVisibility(View.GONE);
            updateMedia();
            return;
        }
        try {
            List<MediaController> list = msm.getActiveSessions(listenerCn);
            msm.addOnActiveSessionsChangedListener(sessionsListener, listenerCn);
            mediaHint.setVisibility(View.GONE);
            pickController(list);
        } catch (Exception e) {
            // Notification access not granted yet: buttons still work through media keys.
            mediaHint.setVisibility(View.VISIBLE);
            setController(null);
        }
    }

    private void disconnectMedia() {
        try {
            if (msm != null) msm.removeOnActiveSessionsChangedListener(sessionsListener);
        } catch (Exception ignored) {
        }
        if (controller != null) {
            controller.unregisterCallback(mediaCallback);
            controller = null;
        }
    }

    private void pickController(List<MediaController> list) {
        MediaController best = null;
        if (list != null) {
            for (MediaController mc : list) {
                PlaybackState st = mc.getPlaybackState();
                if (st != null && st.getState() == PlaybackState.STATE_PLAYING) {
                    best = mc;
                    break;
                }
                if (best == null) best = mc;
            }
        }
        setController(best);
    }

    private void setController(MediaController mc) {
        if (controller != null) controller.unregisterCallback(mediaCallback);
        controller = mc;
        if (mc != null) mc.registerCallback(mediaCallback, ui);
        updateMedia();
    }

    private void updateMedia() {
        MediaMetadata md = controller != null ? controller.getMetadata() : null;
        String title = md != null ? md.getString(MediaMetadata.METADATA_KEY_TITLE) : null;
        String artist = md != null ? md.getString(MediaMetadata.METADATA_KEY_ARTIST) : null;
        Bitmap bmp = null;
        if (md != null) {
            bmp = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
            if (bmp == null) bmp = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
            if (bmp == null) bmp = md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
        }
        songTitle.setText(!TextUtils.isEmpty(title) ? title : "Nothing playing");
        songArtist.setText(!TextUtils.isEmpty(artist) ? artist : "Press play, or tap the cover to open your music app");
        if (bmp != null) art.setImageBitmap(bmp);
        else art.setImageDrawable(null);
        sourceText.setText(controller != null ? appLabel(controller.getPackageName()) : "Media");
        playIcon.setImageResource(isPlaying() ? R.drawable.ic_pause : R.drawable.ic_play);
        updateProgress();
    }

    private boolean isPlaying() {
        if (controller == null) return false;
        PlaybackState s = controller.getPlaybackState();
        return s != null && s.getState() == PlaybackState.STATE_PLAYING;
    }

    private void updateProgress() {
        if (controller == null || controller.getMetadata() == null || controller.getPlaybackState() == null) {
            mediaProgress.setProgress(0);
            return;
        }
        long dur = controller.getMetadata().getLong(MediaMetadata.METADATA_KEY_DURATION);
        PlaybackState s = controller.getPlaybackState();
        long pos = s.getPosition();
        if (s.getState() == PlaybackState.STATE_PLAYING) {
            pos += (long) ((SystemClock.elapsedRealtime() - s.getLastPositionUpdateTime()) * s.getPlaybackSpeed());
        }
        mediaProgress.setProgress(dur > 0 ? (int) Math.max(0, Math.min(1000, pos * 1000 / dur)) : 0);
    }

    private void mediaAction(int keyCode) {
        if (controller != null) {
            MediaController.TransportControls tc = controller.getTransportControls();
            if (keyCode == KeyEvent.KEYCODE_MEDIA_NEXT) tc.skipToNext();
            else if (keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS) tc.skipToPrevious();
            else if (isPlaying()) tc.pause();
            else tc.play();
            return;
        }
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, keyCode));
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, keyCode));
    }

    private String appLabel(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            return pm.getApplicationLabel(ai).toString();
        } catch (Exception e) {
            return "Media";
        }
    }

    // ------------------------------------------------------------------ phone favourites

    private void refreshFavs() {
        favRow.removeAllViews();
        List<String[]> favs = new ArrayList<>();
        try (Cursor c = getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER},
                ContactsContract.CommonDataKinds.Phone.STARRED + "=1", null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")) {
            Set<String> seen = new HashSet<>();
            while (c != null && c.moveToNext() && favs.size() < 4) {
                String name = c.getString(0);
                String num = c.getString(1);
                if (name == null || num == null || !seen.add(name)) continue;
                favs.add(new String[]{name, num});
            }
        } catch (Exception ignored) {
            // No contacts on this head unit, or no permission.
        }

        int[] colors = {0xFF7C3AED, 0xFF0E7490, 0xFFB45309, 0xFFBE185D};
        for (int i = 0; i < 4; i++) {
            final boolean has = i < favs.size();
            final String name = has ? favs.get(i)[0] : "Add favourite";
            final String num = has ? favs.get(i)[1] : null;

            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setBackground(ripple(round(BUTTON, 16), 16));

            TextView circle = new TextView(this);
            circle.setGravity(Gravity.CENTER);
            circle.setTextColor(Color.WHITE);
            circle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
            circle.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            circle.setText(has ? name.substring(0, 1).toUpperCase(Locale.US) : "+");
            circle.setBackground(oval(has ? colors[i] : QUICK_OFF));
            item.addView(circle, new LinearLayout.LayoutParams(dp(58), dp(58)));

            TextView label = new TextView(this);
            label.setText(name);
            label.setTextColor(has ? TEXT : MUTED);
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            label.setSingleLine(true);
            label.setEllipsize(TextUtils.TruncateAt.END);
            label.setGravity(Gravity.CENTER);
            label.setPadding(dp(6), 0, dp(6), 0);
            LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(MATCH, WRAP);
            ll.topMargin = dp(10);
            item.addView(label, ll);

            item.setOnClickListener(v -> {
                if (num != null) {
                    safeStart(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num))));
                } else if (!safeStart(new Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI))) {
                    Toast.makeText(this, "Star a contact in your phone book to add it here.", Toast.LENGTH_LONG).show();
                }
            });

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, MATCH, 1f);
            if (i > 0) lp.leftMargin = dp(10);
            favRow.addView(item, lp);
        }
        phoneSub.setText(favs.isEmpty() ? "Star contacts to show them here" : "Tap a name to call");
    }

    // ------------------------------------------------------------------ small helpers

    private LinearLayout iconLabel(int icon, String text, int iconDp, float sp, int color, boolean vertical, int gapDp) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(vertical ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER);
        ImageView iv = new ImageView(this);
        iv.setImageResource(icon);
        iv.setImageTintList(ColorStateList.valueOf(color));
        iv.setTag("icon");
        l.addView(iv, new LinearLayout.LayoutParams(dp(iconDp), dp(iconDp)));
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(color);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        tv.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        tv.setSingleLine(true);
        tv.setTag("label");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
        if (vertical) lp.topMargin = dp(gapDp);
        else lp.leftMargin = dp(gapDp);
        l.addView(tv, lp);
        l.setClickable(true);
        l.setFocusable(true);
        return l;
    }

    private void tintIconLabel(LinearLayout l, int color) {
        View icon = l.findViewWithTag("icon");
        View label = l.findViewWithTag("label");
        if (icon instanceof ImageView) ((ImageView) icon).setImageTintList(ColorStateList.valueOf(color));
        if (label instanceof TextView) ((TextView) label).setTextColor(color);
    }

    private TextView textButton(String text, int bg, int fg, int radiusDp) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(fg);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setBackground(ripple(round(bg, radiusDp), radiusDp));
        t.setClickable(true);
        t.setFocusable(true);
        return t;
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private GradientDrawable oval(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    /** Touch ripple. radiusDp of -1 means a circle. */
    private Drawable ripple(Drawable content, int radiusDp) {
        Drawable mask = radiusDp < 0 ? oval(Color.WHITE) : round(Color.WHITE, radiusDp);
        return new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), content, mask);
    }

    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }
}
