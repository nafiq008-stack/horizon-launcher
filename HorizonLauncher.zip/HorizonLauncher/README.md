# Horizon Launcher – Proton Persona head unit (Android 6)

A home screen app made for your car's Android 6 head unit, based on the Horizon design.

## What it does

- **Drive tab:** live GPS speed, plus one-tap **Home** and **Work** navigation in Waze, and an **Open Waze** button.
- **Media tab:** the song name, artist and cover of whatever is playing (Spotify, YouTube Music, Bluetooth and so on), with a progress bar and big prev/play/next buttons.
- **Phone tab:** your 4 starred (favourite) contacts, plus Recent calls, Keypad, and a button that opens the head unit's Bluetooth phone app.
- **Clock card:** time, date, outside temperature (from your GPS position) and a greeting.
- **Gold card:** live XAUUSD price that updates every minute, with a small line of today's movement. Tapping it opens MT5 or MT4 if installed.
- **Quick buttons:** brightness slider, volume, and Bluetooth and Wi-Fi on/off. Long-press Bluetooth or Wi-Fi to open their settings.
- **Dock:** Waze, Maps, Music, Video, Radio, Settings, and an **Apps** drawer showing every installed app.

**Long-press any shortcut** (dock buttons, gold card, Open Waze, Phone app, or the album cover) to choose which app it opens.

---

## Step 1 – Build the APK on GitHub (free, about 10 minutes)

You only need a web browser on a PC.

1. Go to **github.com** and sign up or log in.
2. Click **+** (top right) → **New repository**. Name it `horizon-launcher`, keep it **Private**, and click **Create repository**.
3. On the new page, click the link **"uploading an existing file"**.
4. Unzip `HorizonLauncher.zip` on your PC. Open the `HorizonLauncher` folder, select **everything inside it** (`app`, `gradle`, `build.gradle`, `gradlew`, etc.), and drag it all into the GitHub page. Click **Commit changes**.
5. The automatic build file sits in a hidden folder, so add it by hand:
   - Click the **Actions** tab → **set up a workflow yourself**.
   - Delete everything in the editor box.
   - Open `BUILD-WORKFLOW.txt` from the unzipped folder, copy all of it, and paste it into the box.
   - Click **Commit changes** (top right), then **Commit changes** again.
6. Click the **Actions** tab. A build is running (yellow dot). Wait about 5 minutes until it shows a **green tick**.
7. Go back to the repository's main page. On the right side, click **Releases** → **Horizon Launcher build 1** → download **HorizonLauncher.apk**.

If the build shows a **red cross**, open it, copy the red error text and send it to Claude.

## Step 2 – Install on the head unit

1. Copy `HorizonLauncher.apk` to a USB drive and plug it into the car.
2. On the head unit, open **Settings → Security** and turn on **Unknown sources**.
3. Open the head unit's **File manager**, find the APK on the USB drive, tap it, and choose **Install**.
4. Press the **Home** button. When it asks which app to use, pick **Horizon Launcher** and then **Always**.
   - If it doesn't ask, open Horizon from the app list once, then press Home again.
   - Some units only let you change the home app from the factory settings menu. The code is often 8888, 1234 or 0000, but it varies by unit.

## Step 3 – First-time setup (2 minutes)

- **Song names and covers:** go to the Media tab and tap **"Tap here to show song names"**. Turn on **Horizon song info** and press Back. The play buttons work even without this.
- **Waze Home/Work:** save your Home and Work addresses inside Waze first.
- **Favourite contacts:** star contacts in the head unit's phone book. If your contacts only live in the Bluetooth phone app, use the **Phone app** button instead.
- **Radio and Phone app buttons:** tap them once and choose the head unit's own Radio and Bluetooth phone apps.
- **Internet:** the gold price and temperature need internet, for example your phone's hotspot. Everything else works offline.

## Going back to the old home screen

Open **Settings → Apps → Horizon Launcher → Clear defaults**, then press Home and pick the old launcher. You can also simply uninstall Horizon.

## Changing things yourself

- **Greeting name:** `app/src/main/res/values/strings.xml` → `driver_name`
- **Colours:** `app/src/main/res/values/colors.xml`, plus `ACCENT` in `MainActivity.java`

Every time you upload a changed file to GitHub, it builds a new APK automatically.

---

Data sources: gold price from gold-api.com (goldprice.org as backup), weather from Open-Meteo. Both are free and need no account.
